<?php
// vuln.php — reflected XSS demo (unsafe!)
$name = isset($_GET['name']) ? $_GET['name'] : '';
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Reflected XSS Demo</title></head>
<body>
  <h1>Hello</h1>
  <p>Your name: <?php echo $name; ?></p>
  <p>Try: <a href="?name=&lt;script&gt;alert('XSS')&lt;/script&gt;">click this payload link</a></p>
</body>
</html>
