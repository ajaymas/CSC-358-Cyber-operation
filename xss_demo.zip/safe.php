<?php
// safe.php — same behavior but output-escaped (safe)
$name = isset($_GET['name']) ? $_GET['name'] : '';
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Reflected XSS Safe</title></head>
<body>
  <h1>Hello</h1>
  <p>Your name: <?php echo htmlspecialchars($name, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></p>
  <p>Try: <a href="?name=&lt;script&gt;alert('XSS')&lt;/script&gt;">click this payload link</a></p>
</body>
</html>
