XSS Demo (local)
-----------------
Files:
  - vuln.php    : Reflected XSS vulnerable example
  - safe.php    : Same functionality, output-escaped (safe)
  - comment.php : Stored XSS demo (vulnerable - writes to comments.txt)
  - comments.txt: Created when posting via comment.php (optional)

How to run (Linux):
  1. cd into this folder
  2. Start PHP server: php -S 127.0.0.1:8000
  3. Open in browser:
     - http://127.0.0.1:8000/vuln.php
     - http://127.0.0.1:8000/safe.php
     - http://127.0.0.1:8000/comment.php

Testing with curl (examples):
  # Reflected XSS (vulnerable)
  curl "http://127.0.0.1:8000/vuln.php?name=<script>alert('XSS')</script>"

  # Reflected XSS (safe page - escaped)
  curl "http://127.0.0.1:8000/safe.php?name=<script>alert('XSS')</script>"

  # Stored XSS (post a comment)
  curl -X POST -d "comment=<script>alert('STORED')</script>" http://127.0.0.1:8000/comment.php

IMPORTANT:
  - Only test on your local machine or an isolated environment you control.
  - Do NOT test these on third-party websites.
