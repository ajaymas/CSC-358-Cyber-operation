<?php
// comment.php — very small stored-XSS demo (file-backed)
$store = __DIR__ . '/comments.txt';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $c = isset($_POST['comment']) ? $_POST['comment'] : '';
    // NOTE: This intentionally does NOT sanitize to show stored-XSS risk
    file_put_contents($store, $c . "\n", FILE_APPEND | LOCK_EX);
    header('Location: /comment.php');
    exit;
}
$comments = file_exists($store) ? file($store, FILE_IGNORE_NEW_LINES) : [];
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Stored XSS Demo</title></head>
<body>
  <h1>Comments</h1>
  <form method="post">
    <textarea name="comment" rows="3" cols="40"></textarea><br>
    <button type="submit">Post</button>
  </form>

  <h2>All comments</h2>
  <ul>
    <?php foreach ($comments as $c): ?>
      <!-- Vulnerable output: prints raw comment -->
      <li><?php echo $c; ?></li>
    <?php endforeach; ?>
  </ul>
</body>
</html>
